<?php
session_save_path('../tmp');
session_start();
require_once("composedlib/vendor/autoload.php");
use Egulias\EmailValidator\EmailValidator;
use Egulias\EmailValidator\Validation\RFCValidation;
include("conn.php");

if(isset($_POST["submit"])){
$name=$_POST['name'];
$phone=$_POST['phno'];
$password=$_POST['psw1'];
$email=$_POST['email1'];
$add=$_POST['add'];

$name=strip_tags($name);
$phone=strip_tags($phone);
$password=strip_tags($password);
$email=strip_tags($email);
$add=strip_tags($add);

$name=mysqli_real_escape_string($con1,$name);
$phone=mysqli_real_escape_string($con1,$phone);
$password=mysqli_real_escape_string($con1,$password);
$email=mysqli_real_escape_string($con1,$email);
$add=mysqli_real_escape_string($con1,$add);
$userty="u";
$block="nb";
}
$sql="INSERT INTO users VALUES (NULL, '$name','$email','$password', $phone,'$add','$userty','$block')";
if (mysqli_query($con1, $sql)) 
     {
$code = rand(1000,9999);
$_SESSION["code"]=$code;
$addresses = array();
$sub="hi";
$addresses[$email] = $email;
$finalmsg = "<br><h3></h3> Your login code is <u><i><b><br>".$code."</b></i></u><br>";
$transport = (new Swift_SmtpTransport('ssl://smtp.gmail.com', 465))
  ->setUsername('mrbinrecycle21@gmail.com')
  ->setPassword('Mrbin@21');
  $mailer = new Swift_Mailer($transport);
  $message = (new Swift_Message($sub))
 ->setFrom(['mrbinrecycle21@gmail.com'=>'Mr Bin'])
 ->setTo($addresses)
 ->setReplyTo(['mrbinrecycle21@gmail.com'=>'Mr Bin'])
 ->setBody($finalmsg, 'text/html');

$result = $mailer->send($message);

echo "<script>alert('Email Sent Successfully !');window.location.href='otpacc.php';</script>".$result;
     } 
      else 
     {
      echo "Error: " . $sql . "<br>" . mysqli_error($con1);
	 }
?> 