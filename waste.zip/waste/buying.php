<?php
session_save_path('./tmp');
session_start();
include('conn.php');

if(isset($_POST["submit"])){
$weight=$_POST['weight'];
$total=$_POST['total'];
$cat=$_POST['cat'];
$item=$_POST['item'];

$weight=strip_tags($weight);
$total=strip_tags($total);
$cat=strip_tags($cat);
$item=strip_tags($item);

$weight=mysqli_real_escape_string($con1,$weight);
$total=mysqli_real_escape_string($con1,$total);
$cat=mysqli_real_escape_string($con1,$cat);
$item=mysqli_real_escape_string($con1,$item);

$uid=$_SESSION['uid'];
$price=intval($total)*intval($weight);
}


$rqp="INSERT INTO booked VALUES(NULL,$uid,'$cat','$weight','$price','$item')";

if (mysqli_query($con1, $rqp)) 
     {
      echo "<script>alert('Total Payable Amount=Rs$price !');window.location.href='payment.php';</script>";
      echo "<script>alert('Request sent successfully !');window.location.href='payment.php';</script>";
     } 
      else 
     {
    echo "<script>alert('Login First !');window.location.href='index.php';</script>";
	 }
?>
