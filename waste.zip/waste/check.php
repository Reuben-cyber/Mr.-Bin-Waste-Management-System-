<?php
session_save_path('./tmp');
session_start();


include("conn.php");

if(isset($_POST["submit"])){
$user=$_POST['email'];
$pass=$_POST['pass'];
$user=strip_tags($user);
$pass=strip_tags($pass);
$user=mysqli_real_escape_string($con1,$user);
$pass=mysqli_real_escape_string($con1,$pass);
}

$sql="SELECT * FROM users WHERE email='".$user."' AND password='".$pass."'";
$run=mysqli_query($con1,$sql);
$row=mysqli_fetch_array($run,MYSQLI_ASSOC);

if(mysqli_num_rows($run) == 1){
	$_SESSION["loggedin"]=true;
	$_SESSION["uid"] = $row["uid"];
	$_SESSION["userty"]=$row["userty"];
	if($row['block']=="nb"){
	if($row['userty'] == "u"){
		header("Location: indexal.php");
 	}else if($row['userty'] == "a"){
               
		header("Location: admin.php");
 	}
   }else {
		 echo "<script>alert('You are blocked');window.location.href='indexal.php';</script>"; 
	}
	
//mysqli_free_result($con);
mysqli_close($con1);
}else{ 
    echo "<script>alert('Wrong username and / or password!');window.location.href='index.php';</script>";
}
?>	