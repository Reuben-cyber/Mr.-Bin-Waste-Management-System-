<?php
session_save_path('./tmp');
session_start();
?>
<html>
<style>
ul {
  list-style-type: none;
  margin-top:0vw;
  margin-left: -1vw;
  width:100vw;
  padding: 0;
  overflow: hidden;
  background-color:#006200;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>
<head>
  <link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#f6f6f6;">
    <?php
  include('headerad.php');
  ?>
  <ul>
  <li><a class="active" href="personal.php">Personal</a></li>
  <li><a href="verify.php" id="spaceveri">Order Verification</a></li>
  <li><a href="custquery.php" >Customer Queries</a></li>
  <li><a href="addadmin.php" >Add Admin</a></li>
  <li><a href="deleteuser.php" >Delete User</a></li>
  <li><a href="blockuser.php" >Block user</a></li>
   <li><a href="price.php" >Prices</a></li>
</ul>
  <br>
<div style="margin-left:1vw;">
  <table border='1vw solid #000000'>
    <tr>
      <th style="width:15vw;">Email-ID</th>
      <th style="width:20vw;">Subject</th>
      <th style="width:50vw;">Problem</th>
      <th style="width:50vw;">Message</th>
      <th style="width:5vw;">Revert</th>
    </tr>
    <?php
    include('conn.php');
    $sql="Select * from contactus where status='p'";
    $run=mysqli_query($con1,$sql);
    while($row=mysqli_fetch_array($run)){
      $prod_id=$row['cid'];
  ?>
  <tr>
<td><?php echo $row["email"];?></td>
<td><?php echo $row["subject"];?> </td>
<td><?php echo $row["problem"];?> </td>
<td><form action="revert.php?prod_id=<?php echo $row['cid'];?>" method="POST">
<input type="text" name="message" id="message" style="width:35vw; border:none; margin-left: 4vw;" placeholder="Type the message here"></td>
<td><input type="submit" name="submit" id="submit" value="Revert"></form></td>
  </tr>
  <?php
}
  ?>
</table>
</div>
</form>
</td>
</tr>
</body>

  </html>

