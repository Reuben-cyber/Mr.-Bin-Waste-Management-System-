<?php
session_save_path('./tmp');
session_start();
?>
<html >
<style>
a{
	text-decoration:none; color:black;
 }
</style> 
<head>
	<link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#f6f6f6;">
		<?php
	include('headerad.php');
	?>
<div class="inner" style="margin-top: 2vw;">
 <a href="personal.php"><img src="images\personal.png" alt="personal" height="200" width="200" style="margin-left: 10vw; margin-top: 2vw;" /></a>
 <a href="verify.php"><img src="images\requests.jpg" alt="requests" height="200" width="200" style="margin-left: 10vw; margin-top: 2vw;" /></a>
 <a href="custquery.php"><img src="images\service.jpg" alt="service" height="200" width="200" style="margin-left: 10vw; margin-top: 2vw;" /></a>
 <a href="addadmin.php"><img src="images\addadmin.jpg" alt="addadmin" height="200" width="200" style="margin-left: 10vw; margin-top: 2vw;" /></a>
  <br>
 <a href="personal.php"><h3 style="margin-left:13vw;">PERSONAL</h3></a> <a href="verify.php"><h3 style="margin-left:33.5vw; margin-top: -2.7vw;">ORDER VERIFICATION </h3></a> <a href="custquery.php"><h3 style="margin-left:57.5vw; margin-top: -2.7vw;">CUSTOMER QUERIES</h3></a> <a href="addadmin.php"><h3 style="margin-left:84vw; margin-top: -2.7vw;">ADD ADMIN </h3></a>
  </br>
 
 </div>
 <div>
 <a href="deleteuser.php"><img src="images\deleteadmin.jpg" alt="deleteadmin" height="200" width="200" style="margin-left: 21vw; margin-top: 2vw;" /></a>
 <a href="blockuser.php"><img src="images\blockuser.jpg" alt="blockuser" height="200" width="200" style="margin-left: 11vw; margin-top: 2vw;" /></a>
 <a href="price.php"><img src="images\price.jpg" alt="blockuser" height="200" width="200" style="margin-left: 10vw; margin-top: 2vw;" /></a>
 
<br>
  <a href="deleteuser.php"><h3 style="margin-left:23vw;">DELETE USER</h3></a> <a href="blockuser.php"><h3 style="margin-left:48vw; margin-top: -2.7vw;">BLOCK USER</h3></a> <a href="price.php"><h3 style="margin-left:74vw; margin-top: -2.7vw;">RATES</h3></a>
  </br>
  </div>

<?php
  include('footer.php');
  ?>

</html>