<html>
<head>
	<link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#06390d;">
		<?php
	include('header.php');
	?>
	<div class="content">
    <p align="center" style="margin-left: -1vw; margin-top: -1vw;">
    <div class="slideshow-container">
<div class="mySlides">
  <img src="images/food.jpg">
</div>

<div class="mySlides">
  <img src="images/plastic.jpg">
</div>

<div class="mySlides">
  <img src="images/wood.jpg">
</div>

<div class="mySlides">
  <img src="images/ewaste.jpg">
</div>

<div class="mySlides">
  <img src="images/paper.jpeg">
</div>

<div class="mySlides">
  <img src="images/metal.jpeg">
</div>

<div class="mySlides">
  <img src="images/rubber.jpg">
</div>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
  <span class="dot"></span>
  <span class="dot"></span>
  <span class="dot"></span>
</div>

</div>
</p>
</div>
<br>
<div class="rrr">
  <h1><center>Reduce. Recyle. Reuse</center><h1>
  </div>
<!--left side image-->
 <center>
        <div class="space">
        <table>
        <tr>
        <td style="width:30%">
          <img src="images/foodwaste.jpg" alt="food" />
        </td>
        <td style="width:70%">
         <h3>Food Waste</h3>
      <p> We collect leftovers from your homes and give them to the greenhouses and the nurserys associated with us.</p><br>
          <p>They then turn this leftovers into manure.</p>
        </td>
      </tr>
      <tr>
        <td>
          <button style="margin-left:40vw;" onclick="window.location.href='foodb.php'" >Buy</button>
        </td>
        <td>
           <button style="margin-left:1vw;" onclick="window.location.href='food.php'">Donate</button>
        </td>
        </tr>
        </table>
        </div>
        </center>
<!--left side image ends-->

<!--right side image-->
<center>
        <div class="space2">
        <table>
        <tr>
        <td style="width:30%">
          <img src="images/metal.jpeg" alt="metal" />
        </td>
        <td style="width:70%">
        <h3>Metal Waste</h3>
         
      <p>Collection of all metal related items like spare parts,  </p>
      <p>appliances,etc.from your household to the recyclers. </p>
        </td>
        </tr>
         <tr>
        <td>
          <button style="margin-left:5vw;" onclick="window.location.href='metalb.php'">Buy</button>
        </td>
        <td>
           <button style="margin-left:-56vw;" onclick="window.location.href='metal.php'">Sell</button>
        </td>
        </tr>
        </table>
        </div>
        </center>
<!--right side image ends-->

<!--left side image-->
 <center>
        <div class="space" style="margin-top: 2vw;">
        <table>
        <tr>
        <td style="width:30%">
             <img src="images/plastic.jpg" alt="plastic" />
        </td>
        <td style="width:70%">
         <h3>Plastic Waste</h3>
         
      <p>Collection of all plastic related items starting from bottles,showcases,etc to furniture and bigger plastic products.</p><br>
          <p>We collect them all and recycle!</p>
        </td>
        </tr>
        <tr>
        <td>
          <button style="margin-left:40vw;" onclick="window.location.href='plasticb.php'">Buy</button>
        </td>
        <td>
           <button style="margin-left:1vw;" onclick="window.location.href='plastic.php'">Sell</button>
        </td>
        </tr>
        </table>
        </div>
        </center>
<!--left side image ends-->

<!--right side image-->
<center>
        <div class="space2">
        <table>
        <tr>
        <td style="width:30%">
             <img src="images/e2.jpg" alt="ewaste" />
        </td>
        <td style="width:70%">
          <h3>E-Waste </h3>
         
      <p>Collection of all electronic waste items like old </p>
      <p>mobile phones,telephones,laptops,etc.</p>
          <p>We recycle them to for a better future!</p>
        </td>
        </tr>
         <tr>
        <td>
          <button style="margin-left:5vw;" onclick="window.location.href='ewasteb.php'">Buy</button>
        </td>
        <td>
           <button style="margin-left:-56vw;" onclick="window.location.href='ewaste.php'">Sell</button>
        </td>
        </tr>
        </table>
        </div>
        </center>
<!--right side image ends-->

<!--left side image-->
 <center>
        <div class="space" style="margin-top: 2vw;">
        <table>
        <tr>
        <td style="width:30%">
          <img src="images/woodwaste.jpg" alt="wood" />
        </td>
        <td style="width:70%">
          <h3>Wood Waste</h3>
          
      <p>Collection of all wood related items like furnitures, showcases, kitchen utensils,saw-dust,etc. </p><br>
          <p>To create new furniture and better items of them.</p>
        </td>
        </tr>
         <tr>
        <td>
          <button style="margin-left:40vw;" onclick="window.location.href='woodb.php'">Buy</button>
        </td>
        <td>
           <button style="margin-left:1vw;" onclick="window.location.href='wood.php'">Sell</button>
        </td>
        </tr>
        </table>
        </div>
        </center>
<!--left side image ends-->

<!--right side image-->
<center>
        <div class="space2">
        <table>
        <tr>
        <td style="width:30%">
         <img src="images/paper.jpeg" alt="paper" />
        </td>
        <td style="width:70%">
          <h3>Paper Waste</h3>
          
      <p>Collection of old newspapers,calenders,books,</p>
      <p>magazines,etc</p>
          <p>Used to recycle and make handmade paper and</p>
          <p>many more products</p>
        </td>
        </tr>
         <tr>
        <td>
          <button style="margin-left:5vw;" onclick="window.location.href='paperb.php'">Buy</button>
        </td>
        <td>
           <button style="margin-left:-56vw;" onclick="window.location.href='paper.php'">Sell</button>
        </td>
        </tr>
        </table>
        </div>
        </center>
<!--right side image ends-->


<!--left side image-->
 <center>
        <div class="space" style="margin-top: 2vw;">
        <table>
        <tr>
        <td style="width:30%">
          <img src="images/glass.jpg" alt="wood" />
        </td>
        <td style="width:70%">
          <h3>Glass Waste</h3>
          
      <p>Collection of all old glass related items like crockery,mirrors,showcases,etc</p><br>
          <p>And recycling them for newer items.</p>
        </td>
        </tr>
         <tr>
        <td>
          <button style="margin-left:40vw;" onclick="window.location.href='glassb.php'">Buy</button>
        </td>
        <td>
           <button style="margin-left:1vw;" onclick="window.location.href='glass.php'">Sell</button>
        </td>
        </tr>
        </table>
        </div>
        </center>
<!--left side image ends-->

<!--right side image-->
<center>
        <div class="space2">
        <table>
        <tr>
        <td style="width:30%">
         <img src="images/cloth.jpg" alt="paper" />
        </td>
        <td style="width:70%">
          <h3>Textile Waste</h3>
          
      <p>Collection of old rugs,clothes,table cloth,</p><br>
      <p>cotton matresses,etc</p>
      <p>from you and recycling them.</p>
          <p>Recycling them too!!</p>
        </td>
        </tr>
         <tr>
        <td>
          <button style="margin-left:5vw;" onclick="window.location.href='clothb.php'">Buy</button>
        </td>
        <td>
           <button style="margin-left:-56vw;" onclick="window.location.href='cloth.php'">Sell</button>
        </td>
        </tr>
        </table>
        </div>
        </center>
<!--right side image ends-->

<!--left side image-->
 <center>
        <div class="space" style="margin-top: 2vw;">
        <table>
        <tr>
        <td style="width:30%">
          <img src="images/rubber.jpg" alt="wood" />
        </td>
        <td style="width:70%">
          <h3>Rubber Waste</h3>
          
      <p>Collection of all old rubber related items like tyres,spares,etc</p><br>
          <p>And recycling them for newer items.</p>
        </td>
        </tr>
         <tr>
        <td>
          <button style="margin-left:40vw;" onclick="window.location.href='rubberb.php'">Buy</button>
        </td>
        <td>
           <button style="margin-left:1vw;" onclick="window.location.href='rubber.php'">Sell</button>
        </td>
        </tr>
        </table>
        </div>
        </center>
<!--left side image ends-->

<!--right side image-->
<center>
        <div class="space2">
        <table>
        <tr>
        <td style="width:30%">
         <img src="images/construction.jpg" alt="paper" />
        </td>
        <td style="width:70%">
          <h3>Construction Waste</h3>
          
      <p>Collecting ceramic tubs,closets,tiles,concrete debris,etc</p><br>
      <p>from you and recycling them.</p>
        </td>
        </tr>
         <tr>
        <td>
          <button style="margin-left:5vw;" onclick="window.location.href='constructionb.php'">Buy</button>
        </td>
        <td>
           <button style="margin-left:-56vw;" onclick="window.location.href='construction.php'">Sell</button>
        </td>
        </tr>
        </table>
        </div>
        </center>
<!--right side image ends-->

    
    <!--features img start-->
<div style="width:70vw;height:20vw; margin-top:8vw;margin-left:14vw;background-color:#dbdeca; border:0.3vw double #06390d;">

  <h2 style="margin-left:30vw;">FEATURES</h2> 
  <img src="images\f111.jpg" alt="f1" height="120vw" width="120vw" style="margin-left: 7vw; margin-top: 1vw;" />
  
  <img src="images\f222.jpg" alt="f2" height="120vw" width="120vw" style="margin-left: 8vw; margin-top: 1vw;" />
  <img src="images\f333.jpg" alt="f3" height="120vw" width="120vw" style="margin-left: 8vw; margin-top: 1vw;" />
  <img src="images\f555.jpg" alt="f4" height="120vw" width="120vw" style="margin-left: 8vw; margin-top: 1vw;" />
  <br>
  <h3 style="margin-left:7vw;">ONLINE BILL</h3> <h3 style="margin-left:24vw; margin-top: -2.7vw;">PAPERLESS </h3><h3 style="margin-left:40vw; margin-top: -2.7vw;">AUTOMATIC </h3><h3 style="margin-left:58vw; margin-top: -2.7vw;">PICKUP </h3>
  </br>
  <h3 style="margin-left:10vw; margin-top: -2vw;"> PAY </h3><h3 style="margin-left:25vw; margin-top: -3vw;">BILLING</h3>  <h3 style="margin-left:40vw; margin-top: -3vw;"> PAYMENTS </h3> <h3 style="margin-left:57vw; margin-top: -2.6vw;"> SCHEDULE </h3>
  
</div>
 <!--features END-->



<?php
  include('footer.php');
  ?>
  
  

<script type="text/javascript">
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}


</script>
</html>