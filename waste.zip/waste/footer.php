<html>
<style>
.footer{
  background-color:black;
  font-size: 1.3vw;
  width:100vw;
  margin-left:-1vw;
  margin-top:20vw;
  margin-bottom: -1vw;
  height: 3.5vw;
  text-align:center;
  color:white;
}
	</style>
	<body>
<footer class="footer">
	<p align="center"><br>
	Copyright©2021 MrBin.All Rights Reserved.Developed & Designed by:-Aditya Janve,Ashish Surve,Reuben Kurian
</p>
	</footer>
</body>
</html>