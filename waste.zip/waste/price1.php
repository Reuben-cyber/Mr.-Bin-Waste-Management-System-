<?php
session_save_path('./tmp');
session_start();
$uid=$_SESSION['uid'];

include("conn.php");

if(isset($_POST["submit"])){
$cat=$_POST['cat'];
$price=$_POST['price'];

$cat=strip_tags($cat);
$price=strip_tags($price);

$cat=mysqli_real_escape_string($con1,$cat);
$price=mysqli_real_escape_string($con1,$price);

}

$sql="UPDATE prices SET uid='$uid',price='$price' WHERE category='$cat' ";

if (mysqli_query($con1, $sql)) 
     {
      echo "<script>alert('Prices updated Successfully !');window.location.href='price.php';</script>";
     } 
      else 
     {
       echo "<script>alert('Login First !');window.location.href='index.php';</script>";
	 }
?> 