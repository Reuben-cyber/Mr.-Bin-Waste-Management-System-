<?php
include'conn.php';
session_save_path('./tmp');
session_start();

$prod_id=$_GET['prod_id'];

$query="update wastedetails set status='a' where wid='$prod_id'";
$run=mysqli_query($con1,$query);

echo"<script>alert('Verified !');window.location.href='verify.php';</script>";
?>