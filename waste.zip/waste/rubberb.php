<?php
session_save_path('./tmp');
session_start();
include('conn.php');
?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#06390d;">
<?php
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
	include('headeral.php');
}else
{
	include('header.php');
}
?> 

<!--left side image-->
 <center>
  <form method="POST" action="buying.php">
        <div class="space" style="height:37vw; margin-top:1vw;">
        <table>
        <tr>
        <td style="width:30%">
          <img src="images/rubber.jpg" alt="rubber"/>
        </td>
        <td style="width:70%">
         <h3 style=" margin-top:2vw;">Rubber Waste</h3>
      <p>Total amount of rubber waste:-
      	<?php
      	 include('conn.php');
         $sql = "Select SUM(apweight) AS wei from wastedetails where category='rubber' ";
         $rqt="SELECT SUM(weight) AS gw from booked where category='rubber' "; 
         $rty="SELECT price AS re from prices where category='rubber'";

         $sum = mysqli_query($con1,$sql);
         $result= mysqli_fetch_object($sum);

         $fgh=mysqli_query($con1,$rqt);
         $pesult=mysqli_fetch_object($fgh);

         $dfg=mysqli_query($con1,$rty);
         $srd=mysqli_fetch_object($dfg);


         $t=$result->wei- $pesult->gw;
         echo $t;
         echo 'kg';
         if($t==0){
            echo"<font style='color:red;'>&nbsp Out Of Stock!</font>";
         }
         $total=$srd->re;
        
?>
<p>Tyres:-
  <?php
         include('conn.php');
         $sql1 = "Select SUM(apweight) AS wei1 from wastedetails where category='rubber' and item='tyres'";
         $rqt1="SELECT SUM(weight) AS gw1 from booked where category='rubber' and  item='tyres'"; 

         $sum1 = mysqli_query($con1,$sql1);
         $result1= mysqli_fetch_object($sum1);

         $fgh1=mysqli_query($con1,$rqt1);
         $pesult1=mysqli_fetch_object($fgh1);

         echo $result1->wei1- $pesult1->gw1;
         echo 'kg';
        
?>
</p>

<p>Spares:-
  <?php
         include('conn.php');
         $sql2 = "Select SUM(apweight) AS wei2 from wastedetails where category='rubber' and item='spares'";
         $rqt2="SELECT SUM(weight) AS gw2 from booked where category='rubber' and  item='spares'"; 

         $sum2 = mysqli_query($con1,$sql2);
         $result2= mysqli_fetch_object($sum2);

         $fgh2=mysqli_query($con1,$rqt2);
         $pesult2=mysqli_fetch_object($fgh2);

         echo $result2->wei2- $pesult2->gw2;
         echo 'kg';
        
?>
</p>

<p>Bushes:-
  <?php
         include('conn.php');
         $sql3 = "Select SUM(apweight) AS wei3 from wastedetails where category='rubber' and item='bushes'";
         $rqt3="SELECT SUM(weight) AS gw3 from booked where category='rubber' and  item='bushes'"; 

         $sum3 = mysqli_query($con1,$sql3);
         $result3= mysqli_fetch_object($sum3);

         $fgh3=mysqli_query($con1,$rqt3);
         $pesult3=mysqli_fetch_object($fgh3);

         echo $result3->wei3- $pesult3->gw3;
         echo 'kg';
        
?>
</p>


<p>Others:-
  <?php
         include('conn.php');
         $sql7 = "Select SUM(apweight) AS wei7 from wastedetails where category='metal' and item='others'";
         $rqt7="SELECT SUM(weight) AS gw7 from booked where category='metal' and  item='others'"; 

         $sum7 = mysqli_query($con1,$sql7);
         $result7= mysqli_fetch_object($sum7);

         $fgh7=mysqli_query($con1,$rqt7);
         $pesult7=mysqli_fetch_object($fgh7);

         echo $result7->wei7- $pesult7->gw7;
         echo 'kg';
        
?>
</p>


<p>
   <input type="hidden" name="total" id="total" value="<?php echo $total;?>">
   <input type="hidden" name="cat" id="cat" value="rubber">
</p>
<?php 
if($t==0)
{
echo'<p>Your requirement   :- <input type="text" name="weight" id="weight"  class="kilo" style="width:12vw; height: 3.5vw;margin-left:1vw;" value="kg" disabled></p>';
}else{
  echo'<p>Your requirement   :- <input type="text" name="weight" id="weight"  class="kilo" style="width:12vw; height: 3.5vw;margin-left:1vw;" value="kg"></p>';
}
?>

<p>Select category:- &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
  <select name="item" id="item" style="width:12vw;height:3.5vw;font-size:1vw; border-radius: 0vw; border:0.5vw">
     <option value="tyres">Tyres</option>
    <option value="spares">Spares</option>
    <option value="bushes">Bushes</option>
    <option value="others">Others</option>
  </select>
</p>
          <p> Price:-<?php echo $srd->re; ?>/kg</p>
        </td>
      </tr>
      <tr>
        <td>
            <br>
           <?php
            if($t==0)
{
           echo'<input type="submit" name="submit" id="submit" value="Buy" style="margin-left: 40vw;margin-top:1vw;" disabled>';
       }else{
        echo'<input type="submit" name="submit" id="submit" value="Buy" style="margin-left: 40vw;margin-top:1vw;">';
       }
       ?>
           </form>
        </td>
        </tr>
        </table>
        </div>
      
        </center>
<!--left side image ends-->

<?php
include('footer.php');
?>
</body>
</html>

