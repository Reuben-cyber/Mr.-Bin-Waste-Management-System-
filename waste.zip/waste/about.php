<?php
session_save_path('./tmp');
session_start();
include('conn.php');
?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#06390d;">
		<?php
		if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
	include('headeral.php');
}else
{
	include('header.php');
}
?>
<html>
<body>
	<center>
<div  style="width:95vw;height:42vw; margin-top:2vw;margin-left:-1vw;background-color:#dbdeca; border:0.3vw double #06390d;">
<div style="position:absolute;margin-top: 0.5vw;margin-right: 1vw;margin-left: 1vw;text-align: left;">
	<center><h1 style="color:black; font-size: 3vw;"> About Us </h1></center>
	<p style="font-family:verdana;color:black; font-size:1.8vw; font-style: bold;">

<b>MRBIN: A new way to buy and sell Waste!</b></p>

<p style="font-family:verdana; text-align: left; color:black; font-size:1.3vw;">The world is an interconnected ecosystem. We believe that no issue in waste management is isolated.

MRBIN is a revolutionary platform that allows buyers and sellers to connect directly online and make deals
happen faster and more efficiently.</p>

<p style="font-family:verdana; text-align: left; color:black; font-size:1.3vw;">With MRBIN, sellers and buyers manage their profiles, read product and seller reviews.
We offer professional waste collection and processing services to households, corporate clients and waste pickers.</p>

<p style="font-family:verdana; text-align: left;color:black;font-size:1.3vw;">All these features are made simple,with easy access, available through the user’s personal dashboard screen. 
Overall, the platform allows for transparency and efficiency in the buying and selling waste,
eliminating communication barriers and simplifying the process.</p>

<p style="font-family:verdana; text-align: left;color:black;font-size:1.3vw;">We offer Pune's first digital doorstep recyclable pickup service.</p>

<p style="font-family:verdana; text-align: left;color:black;font-size:1.3vw;">We believe in the promise of a greener world tomorrow, built upon the actions of today. 
We believe in more.</p>

<p style="font-family:verdana; text-align: left;color:black;font-size:1.3vw;">For any query please contact mrbinrecycle21@gmail.com.</p>
</div>
</div>
</center>
</body>
<?php
include('footer.php');
?>
</html>