<?php
session_save_path('./tmp');
session_start();
$uid=$_SESSION['uid'];
?>
<html>
<head>
    <style>
ul {
  list-style-type: none;
  margin-top:0vw;
  margin-left: -1vw;
  padding: 0;
  overflow: hidden;
  background-color:#006200;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>
	<link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#06390d;">
		<?php
	include('headeral.php');
	?>
    <ul>
  <li><a href="user.php" >Back</a></li>
  <li><a class="active" href="personaluser.php">Personal</a></li>
  <li><a href="orderstatus.php" id="spaceveri">Order Status</a></li>
</ul>

<?php
		include 'conn.php';
    $query = "SELECT * FROM wastedetails WHERE uid='$uid'";
    $result = mysqli_query($con1,$query);
    while($res = mysqli_fetch_array($result)) {  
        $prod_id=$res['wid'];
    
?> 
<center>
        <div class="space" style="margin-top: 1.5vw;">
        <table>
        <tr>
        <td style="width:30%">
            <?php
        	 $imageURL = 'upload/'.$res["img"];?>
            <img src="<?php echo $imageURL; ?>" />
        </td>
        <td style="width:70%">
        	<h3 style="margin-left:2vw;"><?php echo ucfirst($res ["category"]);?></h3>
			<p style="margin-left:2vw;"> Weight:-<?php echo ucfirst($res ["apweight"]);?>Kg</p>
        	<p style="margin-left:2vw;"> Item:-<?php echo ucfirst($res["item"]);?></p>
        	<p style="margin-left:2vw;">Location:-<?php echo $res ["location"]?></p>
            <p style="margin-left:2vw;">Status:-<?php if($res ["status"]=='p') {echo'Pending';}else{echo'Accepted';}?></p>
        </td>
        </tr>
        </table>
        </div>
        </center>
        
		 <?php
		 }
		
		 ?>
    </body>
    </html>