<html>
<head>
  <link rel="stylesheet" type="text/css" href="style1.css"> 
  </head>
<style>
a:hover
{
  color:#66ff66; 
}
</style>

<body>
  <div style="width:100vw;height:8.3vw; margin-top:-1vw;margin-left:-1vw;background-color:#06390d;">
    <p class="name"><font color:black;></font></p>
    <a href="indexal.php"><img class="logoimg" src="images/logo2.png"></img></a>
    <a href="user.php" style="margin-left:92vw;" class="buttons"><img src="images/user.jpg" style="height:4vw;width:4vw; margin-top: -1vw;"></a>
    <a href="logout.php" style="margin-left: 78vw;" class="buttons">Logout</a>
    <a href="about.php" style="margin-left: 42vw;" class="buttons">About</a>
    <a href="connect.php" style="margin-left: 60vw;" class="buttons">Connect</a>
    <a href="indexal.php" style="margin-left: 26vw;" class="buttons">Home</a>
    </div>
</html>
