<?php
session_save_path('./tmp');
session_start();
include('conn.php');
?>
<html>
 
<head>
	<link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#06390d;">
		<?php
		if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
	include('headeral.php');
}else
{
	include('header.php');
}
?>

<!--left side image-->
 <center>
  <form method="POST" action="buying.php">
        <div class="space" style= "margin-top: 3vw;">
        <table>
        <tr>
        <td style="width:30%">
          <img src="images/foodwaste.jpg" alt="food"/>
        </td>
        <td style="width:70%">
         <h3 style= "margin-top: -4vw;">Food Waste</h3>
      <p>Amount of food we have with us:-
      	<?php
      	include('conn.php');
         $sql = "Select SUM(apweight) AS wei from wastedetails where category='food'";
         $rqt="SELECT SUM(weight) AS gw from booked where category='food'"; 
         $rty="SELECT price AS re from prices where category='food'";
         $sum = mysqli_query($con1,$sql);
         $result= mysqli_fetch_object($sum);

         $fgh=mysqli_query($con1,$rqt);
         $pesult=mysqli_fetch_object($fgh);

         $dfg=mysqli_query($con1,$rty);
         $srd=mysqli_fetch_object($dfg);

         $t=$result->wei- $pesult->gw;
         echo $t;
         echo 'kg';
         if($t==0){
            echo"<font style='color:red;'>&nbsp Out Of Stock!</font>";
         }
         $total=$srd->re;
?>
   <input type="hidden" name="total" id="total" value="<?php echo $total; ?>">
    <input type="hidden" name="cat" id="cat" value="food">
  </p>
<?php
if($t==0)
{
echo'<p>Your requirement in kilos:-  <input type="text" name="weight1" id="weight1"  class="kilo" style="width:9vw; height: 2vw;margin-left:1vw;" value="kg" disabled></p>';
}else{
  echo'<p>Your requirement in kilos:-  <input type="text" name="weight" id="weight"  class="kilo" style="width:9vw; height: 2vw;margin-left:1vw;" value="kg" ></p>';
}
?>
          <p> Price :-<?php echo $srd->re; ?>/kg</p>
        </td>
      </tr>
      <tr>
        <td>
          <input type="hidden" name="item" id="item" value="food">
         <?php
            if($t==0)
             {
           echo'<input type="submit" name="submit" id="submit" value="Buy" style="margin-left: 40vw;margin-top:-3vw;" disabled>';
       }else{
        echo'<input type="submit" name="submit" id="submit" value="Buy" style="margin-left: 40vw;margin-top:-3vw;">';
       }
       ?>
        </td>
        </tr>
        </table>
        </div>
      </form>
        </center>
<!--left side image ends-->
<?php
include('footer.php');
?>
</body>
</html>

