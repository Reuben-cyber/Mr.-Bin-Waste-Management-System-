<?php
session_save_path('./tmp');
session_start();


include("conn.php");

if(isset($_POST["submit"])){
$apweight=$_POST['apweight'];
$picloc=$_POST['picloc'];
$item=$_POST['item'];

$apweight=strip_tags($apweight);
$picloc=strip_tags($picloc);
$item=strip_tags($item);

$apweight=mysqli_real_escape_string($con1,$apweight);
$picloc=mysqli_real_escape_string($con1,$picloc);
$item=mysqli_real_escape_string($con1,$item);

//Logic for file1 upload
$allowedExts = array("jpg", "jpeg", "gif", "png");
$parts = explode(".", $_FILES["file1"]["name"]);
$extension = end($parts);
echo $_FILES["file1"]["tmp_name"];
if ((($_FILES["file1"]["type"] == "image/gif")
|| ($_FILES["file1"]["type"] == "image/jpeg")
|| ($_FILES["file1"]["type"] == "image/png")
|| ($_FILES["file1"]["type"] == "image/jpg"))
&& in_array($extension, $allowedExts))
  {
  if ($_FILES["file1"]["error"] > 0)
    {
    $msg1="Return Code: " . $_FILES["file1"]["error"] . "<br />";
    }
  else
    {
   /* $msg1="Upload: " . $_FILES["file1"]["name"] . "<br />";
    $msg1=$msg1."Type: " . $_FILES["file1"]["type"] . "<br />";
    $msg1=$msg1."Size: " . ($_FILES["file1"]["size"] / 1024) . " Kb<br />";
    $msg1=$msg1."Temp file: " . $_FILES["file1"]["tmp_name"] . "<br />";*/

    if (file_exists("upload/". $_FILES["file1"]["name"]))
      {
      $msg1=$msg1."Since the files already exists rename the file on your comp and upload.";
      }
      else {
      move_uploaded_file($_FILES["file1"]["tmp_name"], "upload/". $_FILES["file1"]["name"]);
      $name=$_FILES["file1"]["name"];
      $msg1=$name;
      }
    }
  }
else
  {
    //exchanged it with the top code instead of the error msg.
  move_uploaded_file($_FILES["file1"]["tmp_name"], "upload/". $_FILES["file1"]["name"]);
       $name=$_FILES["file1"]["name"];
      $msg1=$name;
  }

 $status='p'; 
 $cat='construction';
 $uid=$_SESSION['uid'];
}
$sql="INSERT INTO wastedetails VALUES (NULL,'$uid','$cat','$item','$apweight','$picloc','$status','$msg1')";

if (mysqli_query($con1, $sql)) 
     {
      echo "<script>alert('Request sent successfully ! Our person will contact you immediately');window.location.href='indexal.php';</script>";
     } 
      else 
     {
       echo "<script>alert('Login First !');window.location.href='index.php';</script>";
	 }
?> 