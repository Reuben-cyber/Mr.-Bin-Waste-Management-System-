<?php
include'conn.php';
session_save_path('./tmp');
session_start();
$uid=$_SESSION['uid'];


$query="delete from users where uid='$uid'";
$run=mysqli_query($con1,$query);

echo"<script>alert('You deleted your account !');window.location.href='index.php';</script>";
?>