<html>
<head>
  <link rel="stylesheet" type="text/css" href="style1.css"> 
  </head>
<style>
a:hover
{
  color:#66ff66; 
}
</style>

<body>
  <div style="width:100vw;height:8.3vw; margin-top:-1vw;margin-left:-1vw;background-color:#06390d;">
    <a href="admin.php"><img class="logoimg" src="images/logo2.png"></img></a>
    <p class="name"><font color:black;></font></p>
    <a href="logout.php" style="margin-left: 90vw;" class="buttons">Logout</a>
    </div>
</html>
