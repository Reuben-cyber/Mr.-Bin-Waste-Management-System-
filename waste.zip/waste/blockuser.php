<?php
session_save_path('./tmp');
session_start();
$uid=$_SESSION['uid'];
?>
<html>
<style>
ul {
  list-style-type: none;
  margin-top:0vw;
  margin-left: -1vw;
  width:100vw;
  padding: 0;
  overflow: hidden;
  background-color:#006200;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>
<head>
	<link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#06390d;">
		<?php
	include('headerad.php');
	?>
  <ul>
  <li><a class="active" href="personal.php">Personal</a></li>
  <li><a href="verify.php" id="spaceveri">Order Verification</a></li>
  <li><a href="custquery.php" >Customer Queries</a></li>
  <li><a href="addadmin.php" >Add Admin</a></li>
  <li><a href="deleteuser.php" >Delete User</a></li>
  <li><a href="blockuser.php" >Block user</a></li>
   <li><a href="price.php" >Prices</a></li>
</ul>
 <?php
    include 'conn.php';
    $query = "SELECT * FROM users WHERE uid=$uid";
    $result = mysqli_query($con1,$query);
    while($res = mysqli_fetch_array($result)) {  
  ?>
    <center>
	<div style="width:70vw;height:20vw; margin-top:2vw;margin-left:4vw;background-color:#dbdeca; border:0.3vw double #06390d;">
	<div class="addadmin" >
    <form method="post" action="blockuser1.php" > 
	<h1 style=" margin-top:2vw;">Block User</h1>
    <select name="name" id="name">
 <?php
        include "conn.php";  
        $records = mysqli_query($con1, "SELECT name From users where block='nb'");  

        while($data = mysqli_fetch_array($records))
        {
      $name=$data[0];
            echo "<option value='$name' id='name' name='$name'> $name </option>"; 
        } 
    ?>  
  </select><br>
        <input type="submit" id="submit" name="submit" Value="Block">
		</div>
	  </div>
	  </center>
      <?php
  }
  ?>
  <?php
           include('footer.php');
   ?>
</form>
</body>
</html>