<?php
session_save_path('./tmp');
session_start();
$uid=$_SESSION['uid'];
?>
<html>
<style>
a{
	text-decoration:none; color:black;
 }
</style> 
<head>
	<link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#f6f6f6;">
		<?php
	include('headeral.php');
	?>
<div class="inner" style="margin-top: 2vw;">
 <a href="personaluser.php"><img src="images\personal.png" alt="personal" height="200" width="200" style="margin-left: 15vw; margin-top: 2vw;" /></a>
 <a href="orderstatus.php"><img src="images\requests.jpg" alt="requests" height="200" width="200" style="margin-left: 15vw; margin-top: 2vw;" /></a>
 <a href="deleteaccount.php"><img src="images\deleteadmin.jpg" alt="deleteaccount" height="200" width="200" style="margin-left: 15vw; margin-top: 2vw;" /></a>
 </div>
  <br>
 <a href="personal.php"><h3 style="margin-left:18vw;">PERSONAL</h3></a> <a href="orderstatus.php"><h3 style="margin-left:45vw; margin-top: -2.7vw;">ORDER STATUS </h3></a> <a href="deleteaccount.php"><h3 style="margin-left:72.5vw; margin-top: -2.7vw;">DELETE ACCOUNT</h3></a> 
  </br>

<?php
  include('footer.php');
  ?>
</html>