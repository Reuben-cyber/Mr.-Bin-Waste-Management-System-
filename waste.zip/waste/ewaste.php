<?php
session_save_path('./tmp');
session_start();
?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#f6f6f6;">
		<?php
        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
include'headeral.php';
}else{
    include'header.php';
}
?>
<html>
<style>
	::placeholder {
  color: white;
  opacity: 1;
}
</style>
<body>
<form method="POST" action="ewaste1.php" enctype="multipart/form-data">
<p><input type="file"  accept="image/*" name="file1" id="file1"  onchange="loadFile(event)" style="display: none;"></p>
<center><p style="margin-top: 4vw;"><label for="file1" style="cursor: pointer; font-size: 2vw;">Upload Image(Click Here)</label></p></center>
<center><p><img id="output" width="600" height="300" style="margin-top:0vw;" /></p></center>
<br>
<div class="forminside">
<input type="text" name="apweight" id="apweight" placeholder="Weight in kg" style=" margin-left: 13vw;
              margin-top: 0vw;
}">
<input type="text" name="picloc" id="picloc" placeholder="Pick-up Location">
<select name="item" id="item">
    <option value="laptop">Laptop</option>
    <option value="cpu">CPU</option>
    <option value="speaker">Speaker</option>
    <option value="computer accessories">Computer Accessories</option>
    <option value="home applications">Home Applicances</option>
    <option value="tv">TV/Monitors</option>
    <option value="mobile">Mobile Phones</option>
  </select>
 <br><center> <input type="submit" id="submit" name="submit"></center><br>	
  </div>
</form>
</body>
<script>
var loadFile = function(event) {
	var image = document.getElementById('output');
	image.src = URL.createObjectURL(event.target.files[0]);
};
</script>
<?php
  include('footer.php');
  ?>
</html>
