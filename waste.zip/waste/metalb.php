<?php
session_save_path('./tmp');
session_start();
include('conn.php');
?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#06390d;">
<?php
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
	include('headeral.php');
}else
{
	include('header.php');
}
?> 

<!--left side image-->
 <center>
  <form method="POST" action="buying.php">
        <div class="space" style="height:45vw; margin-top:1vw;border:none;">
        <table>
        <tr>
        <td style="width:30%">
          <img src="images/metal.jpeg" alt="metal"/>
        </td>
        <td style="width:70%">
         <h3 style=" margin-top:2vw;">Metal Waste</h3>
      <p>Total amount of metal waste:-
      	<?php
      	 include('conn.php');
         $sql = "Select SUM(apweight) AS wei from wastedetails where category='metal' ";
         $rqt="SELECT SUM(weight) AS gw from booked where category='metal' "; 
         $rty="SELECT price AS re from prices where category='metal'";

         $sum = mysqli_query($con1,$sql);
         $result= mysqli_fetch_object($sum);

         $fgh=mysqli_query($con1,$rqt);
         $pesult=mysqli_fetch_object($fgh);

         $dfg=mysqli_query($con1,$rty);
         $srd=mysqli_fetch_object($dfg);


        $t=$result->wei- $pesult->gw;
         echo $t;
         echo 'kg';
         if($t<=0){
            echo"<font style='color:red;'>&nbsp Out Of Stock!</font>";
         }
         $total=$srd->re;
        
?>
<p>Applicances:-
  <?php
         include('conn.php');
         $sql1 = "Select SUM(apweight) AS wei1 from wastedetails where category='metal' and item='appliances'";
         $rqt1="SELECT SUM(weight) AS gw1 from booked where category='metal' and  item='appliances'"; 

         $sum1 = mysqli_query($con1,$sql1);
         $result1= mysqli_fetch_object($sum1);

         $fgh1=mysqli_query($con1,$rqt1);
         $pesult1=mysqli_fetch_object($fgh1);

         echo $result1->wei1- $pesult1->gw1;
         echo 'kg';
        
?>
</p>

<p>Battery:-
  <?php
         include('conn.php');
         $sql2 = "Select SUM(apweight) AS wei2 from wastedetails where category='metal' and item='battery'";
         $rqt2="SELECT SUM(weight) AS gw2 from booked where category='metal' and  item='battery'"; 

         $sum2 = mysqli_query($con1,$sql2);
         $result2= mysqli_fetch_object($sum2);

         $fgh2=mysqli_query($con1,$rqt2);
         $pesult2=mysqli_fetch_object($fgh2);

         echo $result2->wei2- $pesult2->gw2;
         echo 'kg';
        
?>
</p>

<p>Kitchen Utensils:-
  <?php
         include('conn.php');
         $sql3 = "Select SUM(apweight) AS wei3 from wastedetails where category='metal' and item='kitchen utensils'";
         $rqt3="SELECT SUM(weight) AS gw3 from booked where category='metal' and  item='kitchen utensils'"; 

         $sum3 = mysqli_query($con1,$sql3);
         $result3= mysqli_fetch_object($sum3);

         $fgh3=mysqli_query($con1,$rqt3);
         $pesult3=mysqli_fetch_object($fgh3);

         echo $result3->wei3- $pesult3->gw3;
         echo 'kg';
        
?>
</p>

<p>Showcase Articles:-
  <?php
         include('conn.php');
         $sql4 = "Select SUM(apweight) AS wei4 from wastedetails where category='metal' and item='showcase articles'";
         $rqt4="SELECT SUM(weight) AS gw4 from booked where category='metal' and  item='showcase articles'"; 

         $sum4 = mysqli_query($con1,$sql4);
         $result4= mysqli_fetch_object($sum4);

         $fgh4=mysqli_query($con1,$rqt4);
         $pesult4=mysqli_fetch_object($fgh4);

         echo $result4->wei4- $pesult4->gw4;
         echo 'kg';
        
?>
</p>

<p>Furniture:-
  <?php
         include('conn.php');
         $sql5 = "Select SUM(apweight) AS wei5 from wastedetails where category='metal' and item='furniture'";
         $rqt5="SELECT SUM(weight) AS gw5 from booked where category='metal' and  item='furniture'"; 

         $sum5 = mysqli_query($con1,$sql5);
         $result5= mysqli_fetch_object($sum5);

         $fgh5=mysqli_query($con1,$rqt5);
         $pesult5=mysqli_fetch_object($fgh5);

         echo $result5->wei5- $pesult5->gw5;
         echo 'kg';
        
?>
</p>

<p>Spare Parts:-
  <?php
         include('conn.php');
         $sql6 = "Select SUM(apweight) AS wei6 from wastedetails where category='metal' and item='spares'";
         $rqt6= "SELECT SUM(weight) AS gw6 from booked where category='metal' and  item='spares'"; 

         $sum6 = mysqli_query($con1,$sql6);
         $result6= mysqli_fetch_object($sum6);

         $fgh6=mysqli_query($con1,$rqt6);
         $pesult6=mysqli_fetch_object($fgh6);

         echo $result6->wei6- $pesult6->gw6;
         echo 'kg';
        
?>
</p>

<p>Other:-
  <?php
         include('conn.php');
         $sql7 = "Select SUM(apweight) AS wei7 from wastedetails where category='metal' and item='others'";
         $rqt7="SELECT SUM(weight) AS gw7 from booked where category='metal' and  item='others'"; 

         $sum7 = mysqli_query($con1,$sql7);
         $result7= mysqli_fetch_object($sum7);

         $fgh7=mysqli_query($con1,$rqt7);
         $pesult7=mysqli_fetch_object($fgh7);

         echo $result7->wei7- $pesult7->gw7;
         echo 'kg';
        
?>
</p>


<p>
   <input type="hidden" name="total" id="total" value="<?php echo $total;?>">
   <input type="hidden" name="cat" id="cat" value="metal">
</p>
<?php
if($t==0)
{
echo'<p>Your requirement   :- <input type="text" name="weight" id="weight"  class="kilo" style="width:12vw; height: 3.5vw;margin-left:1vw;" value="kg" disabled></p>';
}else{
echo'<p>Your requirement   :- <input type="text" name="weight" id="weight"  class="kilo" style="width:12vw; height: 3.5vw;margin-left:1vw;" value="kg" ></p>';
}
?>
<p>Select category:- &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
  <select name="item" id="item" style="width:12vw;height:3.5vw;font-size:1vw; border-radius: 0vw; border:0.5vw">
    <option value="selection">Select Category</option>
    <option value="appliances">Home Appliances</option>
    <option value="battery">Battery</option>
    <option value="kitchen utensils">Kitchen Utensils</option>
    <option value="showcase articles">Showcase Articles</option>
    <option value="furniture">Furniture</option>
    <option value="spares">Spare Parts</option>
    <option value="others">Others</option>
  </select>
</p>
          <p> Price:-<?php echo $srd->re; ?>/kg</p>
        </td>
      </tr>
      <tr>
        <td>
            <br>
            <?php
            if($t==0)
{
           echo'<input type="submit" name="submit" id="submit" value="Buy" style="margin-left: 40vw;margin-top:1vw;" disabled>';
       }else{
        echo'<input type="submit" name="submit" id="submit" value="Buy" style="margin-left: 40vw;margin-top:1vw;">';
       }
       ?>
           </form>
        </td>
        </tr>
        </table>
        </div>
      
        </center>
<!--left side image ends-->

<?php
include('footer.php');
?>
</body>
</html>

