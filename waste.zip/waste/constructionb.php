<?php
session_save_path('./tmp');
session_start();
include('conn.php');
?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#06390d;">
		<?php
		if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
	include('headeral.php');
}else
{
	include('header.php');
}
?>

<!--left side image-->
 <center>
  <form method="POST" action="buying.php">
        <div class="space" style="height:40vw; margin-top:1vw;">
        <table>
        <tr>
        <td style="width:30%">
          <img src="images/construction.jpg" alt="glass"/>
        </td>
        <td style="width:70%">
         <h3 style=" margin-top:2vw;">Construction Waste</h3>
      <p>Amount of construction waste we have with us:-
      	<?php
      	include('conn.php');
         $sql ="Select SUM(apweight) AS wei from wastedetails where category='construction'";
         $rqt="SELECT SUM(weight) AS gw from booked where category='construction'"; 
         $rty="SELECT price AS re from prices where category='construction'";
         $sum = mysqli_query($con1,$sql);
         $result= mysqli_fetch_object($sum);

         $fgh=mysqli_query($con1,$rqt);
         $pesult=mysqli_fetch_object($fgh);

          $dfg=mysqli_query($con1,$rty);
         $srd=mysqli_fetch_object($dfg);

          $t=$result->wei- $pesult->gw;
         echo $t;
         echo 'kg';
         if($t==0){
            echo"<font style='color:red;'>&nbsp Out Of Stock!</font>";
         }
         $total=$srd->re;
?>
<p>Closets:-
  <?php
         include('conn.php');
         $sql1 = "Select SUM(apweight) AS wei1 from wastedetails where category='construction' and item='closets'";
         $rqt1="SELECT SUM(weight) AS gw1 from booked where category='construction' and  item='closets'"; 

         $sum1 = mysqli_query($con1,$sql1);
         $result1= mysqli_fetch_object($sum1);

         $fgh1=mysqli_query($con1,$rqt1);
         $pesult1=mysqli_fetch_object($fgh1);

         echo $result1->wei1- $pesult1->gw1;
         echo 'kg';
        
?>
</p>


<p>Tiles:-
  <?php
         include('conn.php');
         $sql1 = "Select SUM(apweight) AS wei1 from wastedetails where category='construction' and item='tiles'";
         $rqt1="SELECT SUM(weight) AS gw1 from booked where category='construction' and  item='tiles'"; 

         $sum1 = mysqli_query($con1,$sql1);
         $result1= mysqli_fetch_object($sum1);

         $fgh1=mysqli_query($con1,$rqt1);
         $pesult1=mysqli_fetch_object($fgh1);

         echo $result1->wei1- $pesult1->gw1;
         echo 'kg';
        
?>
</p>


<p>Washbasin:-
  <?php
         include('conn.php');
         $sql1 = "Select SUM(apweight) AS wei1 from wastedetails where category='construction' and item='washbasin'";
         $rqt1="SELECT SUM(weight) AS gw1 from booked where category='construction' and  item='washbasin'"; 

         $sum1 = mysqli_query($con1,$sql1);
         $result1= mysqli_fetch_object($sum1);

         $fgh1=mysqli_query($con1,$rqt1);
         $pesult1=mysqli_fetch_object($fgh1);

         echo $result1->wei1- $pesult1->gw1;
         echo 'kg';
        
?>
</p>

<p>Concrete Debris:-
  <?php
         include('conn.php');
         $sql1 = "Select SUM(apweight) AS wei1 from wastedetails where category='construction' and item='debris'";
         $rqt1="SELECT SUM(weight) AS gw1 from booked where category='construction' and  item='debris'"; 

         $sum1 = mysqli_query($con1,$sql1);
         $result1= mysqli_fetch_object($sum1);

         $fgh1=mysqli_query($con1,$rqt1);
         $pesult1=mysqli_fetch_object($fgh1);

         echo $result1->wei1- $pesult1->gw1;
         echo 'kg';
        
?>
</p>


<p>Others:-
  <?php
         include('conn.php');
         $sql1 = "Select SUM(apweight) AS wei1 from wastedetails where category='construction' and item='others'";
         $rqt1="SELECT SUM(weight) AS gw1 from booked where category='construction' and  item='others'"; 

         $sum1 = mysqli_query($con1,$sql1);
         $result1= mysqli_fetch_object($sum1);

         $fgh1=mysqli_query($con1,$rqt1);
         $pesult1=mysqli_fetch_object($fgh1);

         echo $result1->wei1- $pesult1->gw1;
         echo 'kg';
        
?>
</p>


   <input type="hidden" name="total" id="total" value="<?php echo $total; ?>">
   <input type="hidden" name="cat" id="cat" value="construction">
</p>
<?php
if($t==0)
{
echo'<p>Your requirement   :-  <input type="text" name="weight" id="weight"  class="kilo" style="width:12vw; height: 3.5vw;margin-left:1vw;" value="kg" disabled></p>';
}else{
  echo'<p>Your requirement   :-  <input type="text" name="weight" id="weight"  class="kilo" style="width:12vw; height: 3.5vw;margin-left:1vw;" value="kg"></p>';
}
?>
<p>Select category:-&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
 <select name="item" id="item" style="width:12vw;height:3.5vw;font-size:1vw; border-radius: 0vw; border:0.5vw">
    <option value="closets">Closets</option>
    <option value="tiles">Tiles</option>
    <option value="washbasin">Washbasin</option>
    <option value="debris">Concrete Debris</option>
      <option value="others">Others</option>
  </select>
</p>
          <p> Price :<?php echo $srd->re; ?>/kg</p>
        </td>
      </tr>
      <tr>
        <td><br>
          
           <?php
            if($t==0)
{
           echo'<input type="submit" name="submit" id="submit" value="Buy" style="margin-left: 40vw;margin-top:1vw;" disabled>';
       }else{
        echo'<input type="submit" name="submit" id="submit" value="Buy" style="margin-left: 40vw;margin-top:1vw;">';
       }
       ?>
        </td>
        </tr>
        </table>
        </div>
      </form>
        </center>
<!--left side image ends-->
<?php
include('footer.php');
?>
</body>
</html>

