<?php
session_save_path('./tmp');
session_start();
$uid=$_SESSION['uid'];
?>
<html>
<style>
ul {
  list-style-type: none;
  margin-top:0vw;
  margin-left: -1vw;
  width:100vw;
  padding: 0;
  overflow: hidden;
  background-color:#006200;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>

<head>
	<link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#06390d;">
		<?php
	include('headerad.php');
	?>
<ul>
  <li><a class="active" href="personal.php">Personal</a></li>
  <li><a href="verify.php" id="spaceveri">Order Verification</a></li>
  <li><a href="custquery.php" >Customer Queries</a></li>
  <li><a href="addadmin.php" >Add Admin</a></li>
  <li><a href="deleteuser.php" >Delete User</a></li>
  <li><a href="blockuser.php" >Block user</a></li>
   <li><a href="price.php" >Prices</a></li>
</ul>
<center>
<div style="width:60vw;height:28vw; margin-top:2vw;margin-left:4vw;background-color:#dbdeca; border:0.3vw double #06390d;">
  <div class="personal">
    <form method="post" action="price1.php" >
  <h1>Prices</h1>
  <select name="cat" id="cat">
    <option value="food">Food</option>
    <option value="metal">Metal</option>
    <option value="ewaste">Ewaste</option>
    <option value="glass">Glass</option>
     <option value="cloth">Cloth</option>
      <option value="wood">Wood</option>
       <option value="paper">Paper</option>
        <option value="plastic">Plastic</option>
        <option value="rubber">Rubber</option>
        <option value="construction">Construction</option>
  </select>
  <input style=" margin-top:1vw;" type="text" placeholder="Price/Kg" name="price" id="price"><br>
         <input type="submit"  value="Update" id="submit" name="submit">
       </form>
  </div>
</div>
</center>
<?php
include('footer.php');
   ?>
</body>