<?php
include 'header.php';
?>
<body>
	<div style="margin-top: 15vw; ">
	<form method="POST" action="forgot1.php">
<center><input type="email" name="mail" id="mail" placeholder="Enter Your Email-Id"><br><br>
<input type="submit" name="submit" id="submit">
</center>
</form>
</div>
</body>
