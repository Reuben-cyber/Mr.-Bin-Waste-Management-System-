<?php
session_save_path('./tmp');
session_start();
include('conn.php');
?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#06390d;">
		<?php
		if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
	include('headeral.php');
}else
{
	include('header.php');
}

?>
<html>
<body>
	<div style="">
		<center><h1 style="color:white;">PAYMENT PAGE</h1></center>
		<center><img src="images/under.gif" width="500" height="500" style="margin-top: 5vw;"></center>
	</div>
</body>
</html>