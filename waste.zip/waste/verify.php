<?php
session_save_path('./tmp');
session_start();
?>
<html>
<style>
ul {
  list-style-type: none;
  margin-top:0vw;
  margin-left: -1vw;
  width:100vw;
  padding: 0;
  overflow: hidden;
  background-color:#006200;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>
<head>
	<link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#06390d;">
		<?php
	include('headerad.php');
	?>
    <ul>
  <li><a class="active" href="personal.php">Personal</a></li>
  <li><a href="verify.php" id="spaceveri">Order Verification</a></li>
  <li><a href="custquery.php" >Customer Queries</a></li>
  <li><a href="addadmin.php" >Add Admin</a></li>
  <li><a href="deleteuser.php" >Delete User</a></li>
  <li><a href="blockuser.php" >Block user</a></li>
   <li><a href="price.php" >Prices</a></li>
</ul>
<?php
		include 'conn.php';
    $query = "SELECT * FROM wastedetails WHERE status='p'";
    $result = mysqli_query($con1,$query);
    while($res = mysqli_fetch_array($result)) {  
        $prod_id=$res['wid'];
    
?> 
<center>
        <div class="space" style="margin-top:2vw;" >
        <table>
        <tr>
        <td style="width:30%">
            <?php
        	 $imageURL = 'upload/'.$res["img"];?>
            <img src="<?php echo $imageURL; ?>" />
        </td>
        <td style="width:70%">
        	<h3 style="margin-top:-5vw;" ><?php echo ucfirst($res ["category"]);?></h3>
			<p> Weight:-<?php echo ucfirst($res ["apweight"]);?>Kg</p><br>
        	<p> Item:-<?php echo ucfirst($res["item"]);?></p>
        	<p>Location:-<?php echo $res ["location"]?></p>
        </td>
        </tr>
        <tr>
        	<td>
        		<button style="margin-left:40vw;" onclick="window.location.href='accept.php?prod_id=<?php echo $res['wid'];?>'">Accept</button>
        	</td>
        	<td>
           <button onclick="window.location.href='decline.php?prod_id=<?php echo $res['wid'];?>'">Decline</button>
        </td>
        </tr>
        </table>
        </div>
        </center>
        
		 <?php
		 }
		
		 ?>
   <?php
           include('footer.php');
   ?>
    </body>
    </html>