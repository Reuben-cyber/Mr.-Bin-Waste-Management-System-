<?php
session_save_path('./tmp');
session_start();
$uid=$_SESSION['uid'];
?>
<html>
<style>
ul {
  list-style-type: none;
  margin-top:0vw;
  margin-left: -1vw;
  padding: 0;
  overflow: hidden;
  background-color:#006200;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>
<head>
	<link rel="stylesheet" type="text/css" href="style1.css"> 
</head>
<body style="background-color:#06390d;">
		<?php
	include('headeral.php');
	?>
	<ul>
  <li><a href="user.php" >Back</a></li>
  <li><a class="active" href="personaluser.php">Personal</a></li>
  <li><a href="orderstatus.php" id="spaceveri">Order Status</a></li>
</ul>

<?php
	include 'conn.php';
    $query = "SELECT * FROM users WHERE uid=$uid";
    $result = mysqli_query($con1,$query);
    while($res = mysqli_fetch_array($result)) {  
	?>
	<center>
	<div style="width:60vw;height:35vw; margin-top:2vw;margin-left:4vw;background-color:#dbdeca; border:0.3vw double #06390d;">
	<div class="personal" >
	<form method="post" action="updateperuser.php" >
	<h1>Personal Information</h1>
	<input type="text" placeholder="First Last" name="name" id="name" value="<?php echo $res ["name"];?>" required><br>
        <input type="tel" placeholder="Enter Phone Number" name="phno" id="phno" value="<?php echo $res ["phone"];?>"  pattern="^\d{10}$" required><br>
        
        <input type="email" placeholder="Enter Email" name="email1" id="email1" value="<?php echo $res ["email"];?>" required ><br>
        <input type="password" placeholder="Enter Password" name="psw1" id="psw1"  value="<?php echo $res ["password"];?>" required>
         <br>
         <input type="text" placeholder="Enter Address" name="add" id="add"  value="<?php echo $res ["address"];?>" required>
         <br>
          <input type="submit"  value="Update" id="submit" name="submit">
    </div>
	</div>
	</center>
			<?php
	}
	?>
</form>
<?php
           include('footer.php');
   ?>
</body>
</html>
